#pragma once

enum class SeatTypes {
	Free = 'F',
	Reserved = 'R'
};