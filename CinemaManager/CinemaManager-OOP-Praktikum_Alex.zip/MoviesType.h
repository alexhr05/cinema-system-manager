#pragma once

enum class MoviesType {
	ActionMovie = 1,
	DocumentaryMovie = 2,
	DramaMovie = 3,
};